var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var studySchema = new Schema({
    name: String,
    who: String
});
module.exports = mongoose.model('study', studySchema);
