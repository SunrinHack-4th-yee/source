var express = require('express');
var passport = require('passport');
var router = express.Router();
var Board = require('../models/board');
var Comment = require('../models/comment');
var Study = require('../models/study');
var multer = require('multer');
var upload = multer({dest:'../upload/'});
var multiparty = require('multiparty');

// /upload_image POST 요청을 받는 라우터
router.post('/upload', (req, res) => {
    let form = new multiparty.Form({
        autoFiles: true,
        uploadDir: ('../uploads'),
        maxFilesSize: 1024 * 1024 * 5 // 허용 파일 사이즈 최대치
    });

    form.parse(req, (error, fields, files) => {
    	res.json('file uploaded');
    });
});
router.get('/', function(req, res){
  res.render('index', {user : req.user, message : req.flash('signupMessage')}); // 로그인에 성공할시 req.user에 세션값이 담겨있게됩니다.
});

router.get('/register', function(req, res){
  res.render('register', { title: '로그인', link : 'signin', message : req.flash('signinMessage')});
});

router.get('/login', function(req, res){
  res.render('login', { message : req.flash('signinMessage')});
});
router.get('/logout', (req, res) => {
  req.logout();
  res.redirect('/');
});

router.post('/login', passport.authenticate('local-signin', {
  successRedirect : '/',
  failureRedirect : '/login',
  failureFlash : true
}));

router.post('/register', passport.authenticate('local-signup', {
  successRedirect : '/',
  failureRedirect : '/register',
  failureFlash : true
}));

router.post('/upload', upload.single('userfile'), function(req, res){
  res.send('Uploaded : '+req.file.filename);
});
//=============================================================
//스터디
//=============================================================
router.get('/study/new/', function(req, res, next) {
      res.render('study/write',{user : req.user});
});

router.post('/study/join', function (req, res) {
  var study = new Study();
  study.name = req.body.person_name;
  study.who = req.body.study_name;
  study.save(function (err) {
    if(err){
      console.log(err);
      res.redirect('/error');
    }
    res.redirect('http://127.0.0.1:3000/');
  });
});

router.get('/study/view/:sn', function(req, res, next) {
    var sn = req.params.sn;
    Study.find({name:sn},function (err, study) {
      res.render('study/view_study', { study: study ,sn:sn});
      console.log(study);
  });
});


router.get('/study/list', function(req, res, next) {
    Study.find({},function (err, study) {
      res.render('study/view_list', { study: study});
  });
});

//=============================================================
//게시판
//=============================================================
router.get('/member/list/', function(req, res, next) {
  let tag = req.query.tag;
  Board.find({category:"member",tag:tag},function (err, board) {
      res.render('member/list', { title: 'Express', board: board, user : req.user});
      console.log(board);
  });
});

router.get('/question/list', function(req, res, next) {
    let tag = req.query.tag;
  Board.find({category:"question",tag:tag},function (err, board) {
      res.render('question/list', { title: 'Express', board: board });
      console.log(board);
  });
});

/* Write board page */
router.get('/member/write', function(req, res, next) {
    res.render('member/write', { title: '글쓰기',user : req.user, part:"member"});
});

router.get('/question/write', function(req, res, next) {
    res.render('question/write', { title: '글쓰기',user : req.user, part:"question"});
});

/* board insert mongo */
router.post('/member/board/write', function (req, res) {
  var board = new Board();
  board.title = req.body.title;
  board.contents = req.body.contents;
  board.author = req.body.author;
  board.category = req.body.category;
  board.tag = req.body.tag;
  board.save(function (err) {
    if(err){
      console.log(err);
      res.redirect('/');
    }
    res.redirect('http://127.0.0.1:3000/');
  });
});

router.post('/question/board/write', function (req, res) {
  var board = new Board();
  board.title = req.body.title;
  board.contents = req.body.contents;
  board.author = req.body.author;
  board.category = req.body.category;
  board.tag = req.body.tag;
  board.save(function (err) {
    if(err){
      console.log(err);
      res.redirect('/');
    }
    res.redirect('http://127.0.0.1:3000/');
  });
});



/* board find by id */
router.get('/member/board/:id', function (req, res) {
    Board.findOne({_id: req.params.id}, function (err, board) {
        res.render('member/board', { title: 'Board', board: board,user : req.user});
    })
});

router.get('/question/board/:id', function (req, res) {
    Board.findOne({_id: req.params.id}, function (err, board) {
        res.render('member/board', { title: 'Board', board: board,user : req.user});
    })
});

router.post('/member/comment/write', function (req, res){
    var comment = new Comment();
    comment.contents = req.body.contents;
    comment.author = req.body.author;

    Board.findOneAndUpdate({_id : req.body.id}, { $push: { comments : comment}}, function (err, board) {
        if(err){
            console.log(err);
            res.redirect('/');
        }
        res.redirect('/member/board/'+req.body.id);
    });
});

//=============================================================
//질문 게시판
//=============================================================

module.exports = router;
