var express = require('express');
var path = require('path');
var routes = require('./routes');
var passport = require('passport');
var mongoose = require('mongoose');
var session = require('express-session');
var flash = require('connect-flash');
var bodyParser = require('body-parser');
var morgan = require('morgan');
var multer = require('multer');
var fs = require('fs');
var app = express();


require('./models/passport')(passport);

mongoose.connect('mongodb://localhost/appear13');
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function() {
  console.log('Conneted mongoDB');
});
app.use('/data', express.static('uploads'));
app.use(morgan('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

//사용자들에게 좀더 높은 자유도를 허용하기 위해서
var _storage = multer.diskStorage({
  destination:(req, file, cb)=>{
    cb(null, 'uploads/');
  },
  filename: (req, file, cb)=>{
    cb(null, file.originalname);
  }
});
var upload = multer({ storage:_storage});


// view 설정
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, 'public')));
app.use('/upload',express.static('uploads'));
var upload = multer({ dest: 'uploads/' })
app.use(session({
  secret: '비밀코드',
  resave: true,
  saveUninitialized: true
})); // 세션 활성화

// flash는 세션을 필요로합니다. session 아래에 선언해주셔야합니다.
app.use(flash());

// passport 초기화 =
app.use(passport.initialize());
app.use(passport.session());


app.use('/', routes);

app.listen(3000);
